(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7879:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
;// CONCATENATED MODULE: ./styles/theme.js

/*
To Use:
- Add another field/object if needed in the global theme. (eg, breakpoints, typography, sizes, etc)
- If making styled components outside a function, can access this by calling theme.palette.primary.main as an example
- If needed inside the function, must call "const theme = useTheme();" first before you can access.
 */ const theme = (0,styles_.createTheme)({
    palette: {
        primary: {
            main: "#ed8929",
            light: "#fcbd71"
        },
        secondary: {
            main: "#242f3d",
            dark: "#131921",
            contrastText: "white"
        },
        background: {
            main: "#e3e6e6"
        }
    }
});

// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: external "redux-persist/integration/react"
const react_namespaceObject = require("redux-persist/integration/react");
;// CONCATENATED MODULE: external "redux-persist"
const external_redux_persist_namespaceObject = require("redux-persist");
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: external "@redux-devtools/extension"
const extension_namespaceObject = require("@redux-devtools/extension");
;// CONCATENATED MODULE: external "redux-thunk"
const external_redux_thunk_namespaceObject = require("redux-thunk");
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_namespaceObject);
;// CONCATENATED MODULE: external "next-redux-wrapper"
const external_next_redux_wrapper_namespaceObject = require("next-redux-wrapper");
;// CONCATENATED MODULE: external "redux-persist/lib/storage"
const storage_namespaceObject = require("redux-persist/lib/storage");
var storage_default = /*#__PURE__*/__webpack_require__.n(storage_namespaceObject);
;// CONCATENATED MODULE: ./actions/types.js
// Authentication
const REGISTER_SUCCESS = "REGISTER_SUCCESS";
const RESET_REGISTER_SUCCESS = "RESET_REGISTER_SUCCESS";
const REGISTER_FAIL = "REGISTER_FAIL";
const LOGIN_SUCCESS = "LOGIN_SUCCESS";
const LOGIN_FAIL = "LOGIN_FAIL";
const LOGOUT_SUCCESS = "LOGOUT_SUCCESS";
const LOGOUT_FAIL = "LOGOUT_FAIL";
const LOAD_USER_SUCCESS = "LOAD_USER_SUCCESS";
const LOAD_USER_FAIL = "LOAD_USER_FAIL";
const AUTH_SUCCESS = "AUTH_SUCCESS";
const AUTH_FAIL = "AUTH_FAIL";
const REFRESH_SUCCESS = "REFRESH_SUCCESS";
const REFRESH_FAIL = "REFRESH_FAIL";
const SET_AUTH_LOADING = "SET_AUTH_LOADING";
const REMOVE_AUTH_LOADING = "REMOVE_AUTH_LOADING";

;// CONCATENATED MODULE: ./reducers/auth.js

const initialState = {
    user: null,
    isAuthenticated: false,
    loading: false,
    register_success: false,
    token_refresh_complete: false,
    token_check_complete: false
};
const authReducer = (state = initialState, action)=>{
    const { type , payload  } = action;
    switch(type){
        case REGISTER_SUCCESS:
            return {
                ...state,
                register_success: true
            };
        case RESET_REGISTER_SUCCESS:
            return {
                ...state,
                register_success: false
            };
        case LOGIN_SUCCESS:
            return {
                ...state,
                isAuthenticated: true
            };
        case LOGIN_FAIL:
            return {
                ...state,
                isAuthenticated: false
            };
        case LOGOUT_SUCCESS:
            return {
                ...state,
                isAuthenticated: false,
                user: null
            };
        case LOGOUT_FAIL:
            return {
                ...state
            };
        case LOAD_USER_SUCCESS:
            return {
                ...state,
                user: payload.user
            };
        case LOAD_USER_FAIL:
            return {
                ...state,
                user: null
            };
        case AUTH_SUCCESS:
            return {
                ...state,
                isAuthenticated: true,
                token_check_complete: true
            };
        case AUTH_FAIL:
            return {
                ...state,
                isAuthenticated: false,
                user: null,
                token_check_complete: true
            };
        case REFRESH_SUCCESS:
            return {
                ...state,
                token_refresh_complete: true
            };
        case REFRESH_FAIL:
            return {
                ...state,
                isAuthenticated: false,
                user: null,
                token_refresh_complete: true
            };
        case REGISTER_FAIL:
            return {
                ...state
            };
        case SET_AUTH_LOADING:
            return {
                ...state,
                loading: true
            };
        case REMOVE_AUTH_LOADING:
            return {
                ...state,
                loading: false
            };
        default:
            return state;
    }
};
/* harmony default export */ const auth = (authReducer);

;// CONCATENATED MODULE: ./reducers/index.js


// So can call by 'auth' instead of 'authReducer'
/* harmony default export */ const reducers = ((0,external_redux_namespaceObject.combineReducers)({
    auth: auth
}));

;// CONCATENATED MODULE: ./store.js








let store;
const persistConfig = {
    key: "root",
    storage: (storage_default())
};
const persistedReducer = (0,external_redux_persist_namespaceObject.persistReducer)(persistConfig, reducers);
function makeStore(initialState) {
    return (0,external_redux_namespaceObject.createStore)(persistedReducer, initialState, (0,extension_namespaceObject.composeWithDevTools)((0,external_redux_namespaceObject.applyMiddleware)((external_redux_thunk_default()))));
}
const initializeStore = (preloadedState)=>{
    let _store = store ?? makeStore(preloadedState);
    // After navigating to a page with an initial Redux state, merge that state
    // with the current state in the store, and create a new store
    if (preloadedState && store) {
        _store = makeStore({
            ...store.getState(),
            ...preloadedState
        });
        // Reset the current store
        store = undefined;
    }
    // For SSG and SSR always create a new store
    if (true) return _store;
    // Create the store once in the client
    if (!store) store = _store;
    return _store;
};
function useStore(initialState) {
    const store = (0,external_react_.useMemo)(()=>initializeStore(initialState), [
        initialState
    ]);
    return store;
}

// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
;// CONCATENATED MODULE: ./pages/_app.js









function PageLayout({ children , Component  }) {
    const getLayout = Component.getLayout || ((page)=>page);
    return getLayout(children);
}
function MyApp({ Component , pageProps: { session , ...pageProps }  }) {
    const store = useStore(pageProps.initialReduxState);
    const persistor = (0,external_redux_persist_namespaceObject.persistStore)(store, {}, ()=>persistor.persist());
    return /*#__PURE__*/ jsx_runtime_.jsx(external_react_redux_.Provider, {
        store: store,
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_namespaceObject.PersistGate, {
            persistor: persistor,
            loading: null,
            children: /*#__PURE__*/ jsx_runtime_.jsx(react_.SessionProvider, {
                session: session,
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.ThemeProvider, {
                    theme: theme,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(PageLayout, {
                        Component: Component,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                            ...pageProps
                        })
                    })
                })
            })
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 8442:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material/styles");

/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7879));
module.exports = __webpack_exports__;

})();