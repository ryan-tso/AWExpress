exports.id = 65;
exports.ids = [65];
exports.modules = {

/***/ 9399:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Home_container__bCOhY",
	"main": "Home_main__nLjiQ",
	"footer": "Home_footer____T7K",
	"title": "Home_title__T09hD",
	"description": "Home_description__41Owk",
	"code": "Home_code__suPER",
	"grid": "Home_grid__GxQ85",
	"card": "Home_card___LpL1",
	"logo": "Home_logo__27_tb"
};


/***/ }),

/***/ 2845:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Loader)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1223);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_loader_spinner__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9048);
/* harmony import */ var _mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_2__);



/*
Props:
    contained=false
    size=40, 100
    color="#a8cac9", "#297575"
 */ function Loader(props) {
    if (props.contained) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            style: {
                display: "flex",
                alignContent: "center",
                justifyContent: "center",
                color: props.color ?? "#a8cac9"
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CircularProgress__WEBPACK_IMPORTED_MODULE_2___default()), {
                "aria-label": "loading",
                color: "inherit",
                size: props.size ?? 40
            })
        });
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            style: {
                position: "fixed",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)"
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loader_spinner__WEBPACK_IMPORTED_MODULE_1__.RevolvingDot, {
                height: props.size ?? 100,
                width: props.size ?? 100,
                color: props.color ?? "#297575",
                "aria-label": "loading"
            })
        });
    }
}


/***/ }),

/***/ 5065:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ExamplePage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9399);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_utilities_loader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2845);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _layouts_Navbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(834);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _faker_js_faker__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9182);
/* harmony import */ var _components_ProductCard__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4966);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_faker_js_faker__WEBPACK_IMPORTED_MODULE_10__]);
_faker_js_faker__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];













function ExamplePage() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_6__.useTheme)(); // To access universal theme
    const [number, setNumber] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(1); //Keeps track of number variable.  Modify using setNumber only.
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false); // Keeps track of isLoading variable. Modify using setLoading only.
    const [fakeData, setFakeData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]); // to keep track of fake products
    // This runs everytime when the component loads, and everytime the dependents 'loading' changes
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setNumber(number - 1);
    }, [
        loading
    ]);
    // Need to create the fake data before components load or else race condition, do it in useEffect
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        let fakeArray = [];
        for(let i = 0; i < 20; i++){
            fakeArray.push({
                id: i,
                name: _faker_js_faker__WEBPACK_IMPORTED_MODULE_10__.faker.commerce.productName(),
                price: _faker_js_faker__WEBPACK_IMPORTED_MODULE_10__.faker.commerce.price(),
                description: _faker_js_faker__WEBPACK_IMPORTED_MODULE_10__.faker.lorem.paragraph()
            });
        }
        setFakeData(fakeArray);
    }, []);
    // Helper function that a button can activate
    const handleClick = ()=>{
        setNumber(number + 1);
    };
    // Put the JSX HTML in the return.  Can put as many child components as you want.
    // Wrap all javascript with {} to separate it from the HTML
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_12___default().container),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Example Page!"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_12___default().main),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: (_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_12___default().title),
                        children: "Example Page!"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        children: number
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                        variant: "outlined",
                        sx: {
                            color: theme.palette.primary.main,
                            "&:hover": {
                                backgroundColor: theme.palette.secondary.main
                            }
                        },
                        onClick: handleClick,
                        children: "Increase!"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                        variant: "outlined",
                        color: "warning",
                        sx: {
                            "&:hover": {
                                backgroundColor: "lightgrey"
                            }
                        },
                        onClick: ()=>setLoading(!loading),
                        children: [
                            !loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                children: "Load"
                            }),
                            loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_utilities_loader__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                contained: true,
                                size: 150,
                                color: "#a8cac9"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                        sx: {
                            mt: 5,
                            "&:hover": {
                                color: theme.palette.primary.main,
                                cursor: "pointer"
                            }
                        },
                        variant: "h6",
                        onClick: ()=>{
                            router.push("/exampleForm") // Redirects and puts a history item on the stack
                            ;
                        },
                        children: "Click here for example form with Formik"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                        sx: {
                            mt: 10,
                            "&:hover": {
                                color: theme.palette.primary.main,
                                cursor: "pointer"
                            }
                        },
                        variant: "h3",
                        onClick: ()=>{
                            router.replace("/home") // Redirects, but user cannot go back.
                            ;
                        },
                        children: "Click here to go to homepage"
                    }),
                    fakeData.map((item, key)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProductCard__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            name: item.name,
                            description: item.description,
                            price: item.price
                        }, item.id))
                ]
            })
        ]
    });
}
// Add this to put the Navbar layout on this page
ExamplePage.getLayout = (page)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layouts_Navbar__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        children: page
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;