"use strict";
exports.id = 834;
exports.ids = [834];
exports.modules = {

/***/ 834:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ NavbarLayout)
});

// UNUSED EXPORTS: getServerSideProps

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "@mui/material/Box"
var Box_ = __webpack_require__(19);
var Box_default = /*#__PURE__*/__webpack_require__.n(Box_);
// EXTERNAL MODULE: external "@mui/material/Avatar"
var Avatar_ = __webpack_require__(2120);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar_);
// EXTERNAL MODULE: external "@mui/material/Menu"
var Menu_ = __webpack_require__(8125);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
// EXTERNAL MODULE: external "@mui/material/MenuItem"
var MenuItem_ = __webpack_require__(9271);
var MenuItem_default = /*#__PURE__*/__webpack_require__.n(MenuItem_);
// EXTERNAL MODULE: external "@mui/material/ListItemIcon"
var ListItemIcon_ = __webpack_require__(3787);
var ListItemIcon_default = /*#__PURE__*/__webpack_require__.n(ListItemIcon_);
// EXTERNAL MODULE: external "@mui/material/Divider"
var Divider_ = __webpack_require__(3646);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider_);
// EXTERNAL MODULE: external "@mui/material/IconButton"
var IconButton_ = __webpack_require__(7934);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(7163);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);
// EXTERNAL MODULE: external "@mui/material/Tooltip"
var Tooltip_ = __webpack_require__(7229);
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip_);
// EXTERNAL MODULE: external "@mui/icons-material/PersonAdd"
var PersonAdd_ = __webpack_require__(5905);
// EXTERNAL MODULE: external "@mui/icons-material/Settings"
var Settings_ = __webpack_require__(32);
// EXTERNAL MODULE: external "@mui/icons-material/Logout"
var Logout_ = __webpack_require__(9801);
var Logout_default = /*#__PURE__*/__webpack_require__.n(Logout_);
// EXTERNAL MODULE: external "@mui/icons-material/ShoppingCart"
var ShoppingCart_ = __webpack_require__(7248);
var ShoppingCart_default = /*#__PURE__*/__webpack_require__.n(ShoppingCart_);
// EXTERNAL MODULE: external "@mui/icons-material/ShoppingBag"
var ShoppingBag_ = __webpack_require__(6983);
var ShoppingBag_default = /*#__PURE__*/__webpack_require__.n(ShoppingBag_);
// EXTERNAL MODULE: external "@mui/icons-material/AccountCircle"
var AccountCircle_ = __webpack_require__(1883);
var AccountCircle_default = /*#__PURE__*/__webpack_require__.n(AccountCircle_);
// EXTERNAL MODULE: external "@mui/icons-material/Sell"
var Sell_ = __webpack_require__(7026);
var Sell_default = /*#__PURE__*/__webpack_require__.n(Sell_);
// EXTERNAL MODULE: external "@mui/icons-material/Storefront"
var Storefront_ = __webpack_require__(7458);
var Storefront_default = /*#__PURE__*/__webpack_require__.n(Storefront_);
;// CONCATENATED MODULE: ./layouts/Navbar/AccountMenu.js






















function AccountMenu(props) {
    const router = (0,router_.useRouter)();
    const [anchorEl, setAnchorEl] = external_react_.useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
    };
    const logOut = ()=>{
        (0,react_.signOut)({
            callbackURL: "/login"
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                sx: {
                    display: "flex",
                    alignItems: "center",
                    textAlign: "center"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                    title: "Account settings",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                        onClick: handleClick,
                        size: "small",
                        sx: {
                            ml: 2
                        },
                        "aria-controls": open ? "account-menu" : undefined,
                        "aria-haspopup": "true",
                        "aria-expanded": open ? "true" : undefined,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                            src: props.user.image,
                            sx: {
                                width: 32,
                                height: 32
                            },
                            children: props.user.name
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Menu_default()), {
                anchorEl: anchorEl,
                id: "account-menu",
                open: open,
                onClose: handleClose,
                onClick: handleClose,
                PaperProps: {
                    elevation: 0,
                    sx: {
                        overflow: "visible",
                        filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
                        mt: 1.5,
                        "& .MuiAvatar-root": {
                            width: 32,
                            height: 32,
                            ml: -0.5,
                            mr: 1
                        },
                        "&:before": {
                            content: '""',
                            display: "block",
                            position: "absolute",
                            top: 0,
                            right: 14,
                            width: 10,
                            height: 10,
                            bgcolor: "background.paper",
                            transform: "translateY(-50%) rotate(45deg)",
                            zIndex: 0
                        }
                    }
                },
                transformOrigin: {
                    horizontal: "right",
                    vertical: "top"
                },
                anchorOrigin: {
                    horizontal: "right",
                    vertical: "bottom"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/profile",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                            onClick: handleClose,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((AccountCircle_default()), {
                                    sx: {
                                        color: "grey"
                                    }
                                }),
                                " My Account"
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/cart",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                            onClick: handleClose,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((ShoppingCart_default()), {
                                    sx: {
                                        color: "grey"
                                    }
                                }),
                                " Shopping Cart"
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/orders",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                            onClick: handleClose,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((ShoppingBag_default()), {
                                    sx: {
                                        color: "grey"
                                    }
                                }),
                                " Orders"
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/listings",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                            onClick: handleClose,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Storefront_default()), {
                                    sx: {
                                        color: "grey"
                                    }
                                }),
                                " Listings"
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                            onClick: logOut,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Logout_default()), {
                                    sx: {
                                        color: "grey"
                                    }
                                }),
                                " Logout"
                            ]
                        })
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8442);
// EXTERNAL MODULE: external "@mui/material/Drawer"
var Drawer_ = __webpack_require__(7898);
var Drawer_default = /*#__PURE__*/__webpack_require__.n(Drawer_);
// EXTERNAL MODULE: external "@mui/material/CssBaseline"
var CssBaseline_ = __webpack_require__(4960);
var CssBaseline_default = /*#__PURE__*/__webpack_require__.n(CssBaseline_);
// EXTERNAL MODULE: external "@mui/material/AppBar"
var AppBar_ = __webpack_require__(3882);
var AppBar_default = /*#__PURE__*/__webpack_require__.n(AppBar_);
// EXTERNAL MODULE: external "@mui/material/Toolbar"
var Toolbar_ = __webpack_require__(1431);
var Toolbar_default = /*#__PURE__*/__webpack_require__.n(Toolbar_);
// EXTERNAL MODULE: external "@mui/material/List"
var List_ = __webpack_require__(4192);
var List_default = /*#__PURE__*/__webpack_require__.n(List_);
// EXTERNAL MODULE: external "@mui/icons-material/Menu"
var icons_material_Menu_ = __webpack_require__(3365);
var icons_material_Menu_default = /*#__PURE__*/__webpack_require__.n(icons_material_Menu_);
// EXTERNAL MODULE: external "@mui/icons-material/ChevronLeft"
var ChevronLeft_ = __webpack_require__(6959);
var ChevronLeft_default = /*#__PURE__*/__webpack_require__.n(ChevronLeft_);
// EXTERNAL MODULE: external "@mui/icons-material/ChevronRight"
var ChevronRight_ = __webpack_require__(2818);
var ChevronRight_default = /*#__PURE__*/__webpack_require__.n(ChevronRight_);
// EXTERNAL MODULE: external "@mui/material/ListItem"
var ListItem_ = __webpack_require__(2367);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem_);
// EXTERNAL MODULE: external "@mui/material/ListItemButton"
var ListItemButton_ = __webpack_require__(1011);
var ListItemButton_default = /*#__PURE__*/__webpack_require__.n(ListItemButton_);
// EXTERNAL MODULE: external "@mui/material/ListItemText"
var ListItemText_ = __webpack_require__(8315);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText_);
// EXTERNAL MODULE: external "@mui/icons-material/MoveToInbox"
var MoveToInbox_ = __webpack_require__(8307);
// EXTERNAL MODULE: external "@mui/icons-material/Mail"
var Mail_ = __webpack_require__(9026);
// EXTERNAL MODULE: external "@mui/icons-material/AdminPanelSettings"
var AdminPanelSettings_ = __webpack_require__(6213);
var AdminPanelSettings_default = /*#__PURE__*/__webpack_require__.n(AdminPanelSettings_);
;// CONCATENATED MODULE: ./layouts/Navbar/Drawer.js



























const drawerWidth = 240;
const DrawerHeader = (0,styles_.styled)("div")(({ theme  })=>({
        display: "flex",
        alignItems: "center",
        padding: theme.spacing(0, 1),
        // necessary for content to be below app bar
        ...theme.mixins.toolbar,
        justifyContent: "flex-end"
    }));
function PersistentDrawerLeft(props) {
    const theme = (0,styles_.useTheme)();
    const [open, setOpen] = external_react_.useState(false);
    const handleDrawerOpen = ()=>{
        setOpen(true);
    };
    const handleDrawerClose = ()=>{
        setOpen(false);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
        sx: {
            display: "flex",
            position: "fixed"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((CssBaseline_default()), {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Drawer_default()), {
                sx: {
                    width: drawerWidth,
                    flexShrink: 0,
                    "& .MuiDrawer-paper": {
                        width: drawerWidth,
                        boxSizing: "border-box"
                    }
                },
                variant: "persistent",
                anchor: "left",
                open: props.open,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(DrawerHeader, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            onClick: handleDrawerClose,
                            children: theme.direction === "ltr" ? /*#__PURE__*/ jsx_runtime_.jsx((ChevronLeft_default()), {}) : /*#__PURE__*/ jsx_runtime_.jsx((ChevronRight_default()), {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                    /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                        children: [
                            "Account",
                            "Orders",
                            "Listings",
                            "Sell"
                        ].map((text, index)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Link, {
                                href: [
                                    "/profile",
                                    "/orders",
                                    "/listings",
                                    "/sell"
                                ].at(index),
                                children: /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                    disablePadding: true,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItemButton_default()), {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((AccountCircle_default()), {}),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((ShoppingBag_default()), {}),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Storefront_default()), {}),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Sell_default()), {})
                                                ].at(index)
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                primary: text
                                            })
                                        ]
                                    })
                                }, text)
                            }))
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                    /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                        children: [
                            "Admin"
                        ].map((text, index)=>/*#__PURE__*/ jsx_runtime_.jsx(material_.Link, {
                                href: [
                                    "/admin"
                                ].at(index),
                                children: /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                    disablePadding: true,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItemButton_default()), {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((AdminPanelSettings_default()), {})
                                                ].at(index)
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                primary: text
                                            })
                                        ]
                                    })
                                }, text)
                            }))
                    })
                ]
            })
        ]
    });
}

// EXTERNAL MODULE: external "@mui/material/InputBase"
var InputBase_ = __webpack_require__(8855);
var InputBase_default = /*#__PURE__*/__webpack_require__.n(InputBase_);
// EXTERNAL MODULE: external "@mui/material/Badge"
var Badge_ = __webpack_require__(5168);
var Badge_default = /*#__PURE__*/__webpack_require__.n(Badge_);
// EXTERNAL MODULE: external "@mui/icons-material/Search"
var Search_ = __webpack_require__(8017);
var Search_default = /*#__PURE__*/__webpack_require__.n(Search_);
// EXTERNAL MODULE: external "@mui/icons-material/Notifications"
var Notifications_ = __webpack_require__(1567);
// EXTERNAL MODULE: external "@mui/icons-material/MoreVert"
var MoreVert_ = __webpack_require__(6952);
var MoreVert_default = /*#__PURE__*/__webpack_require__.n(MoreVert_);
// EXTERNAL MODULE: external "next-auth/next"
var next_ = __webpack_require__(2113);
// EXTERNAL MODULE: ./pages/api/auth/[...nextauth].js
var _nextauth_ = __webpack_require__(2535);
;// CONCATENATED MODULE: ./layouts/Navbar/index.js































const TOOLBAR_HEIGHT = 50;
const MainStyle = (0,styles_.styled)("div")(({ theme  })=>({
        flexGrow: 1,
        overflow: "auto",
        minHeight: "100%",
        marginTop: TOOLBAR_HEIGHT + 50,
        paddingBottom: 5
    }));
const ToolbarStyle = (0,styles_.styled)((Toolbar_default()))(({ theme  })=>({
        "@media all": {
            minHeight: TOOLBAR_HEIGHT
        },
        backgroundColor: theme.palette.secondary.main
    }));
const Search = (0,styles_.styled)("div")(({ theme  })=>({
        position: "relative",
        borderRadius: theme.shape.borderRadius,
        backgroundColor: (0,styles_.alpha)(theme.palette.common.white, 0.60),
        "&:hover": {
            backgroundColor: (0,styles_.alpha)(theme.palette.common.white, 0.90)
        },
        marginRight: theme.spacing(2),
        marginLeft: 0,
        width: "100%",
        [theme.breakpoints.up("sm")]: {
            marginLeft: theme.spacing(3),
            width: "auto"
        }
    }));
const SearchIconWrapper = (0,styles_.styled)("div")(({ theme  })=>({
        padding: theme.spacing(0, 2),
        height: "100%",
        position: "absolute",
        pointerEvents: "none",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
    }));
const StyledInputBase = (0,styles_.styled)((InputBase_default()))(({ theme  })=>({
        color: "inherit",
        "& .MuiInputBase-input": {
            padding: theme.spacing(1, 1, 1, 0),
            // vertical padding + font size from searchIcon
            paddingLeft: `calc(1em + ${theme.spacing(4)})`,
            transition: theme.transitions.create("width"),
            width: "100%",
            [theme.breakpoints.up("md")]: {
                width: "20ch"
            }
        }
    }));
function NavbarLayout({ children  }) {
    const theme = (0,styles_.useTheme)();
    const router = (0,router_.useRouter)();
    const { data: session , status  } = (0,react_.useSession)();
    const [anchorEl, setAnchorEl] = (0,external_react_.useState)(null);
    const [isDrawerOpen, setDrawer] = (0,external_react_.useState)(false);
    const [mobileMoreAnchorEl, setMobileMoreAnchorEl] = (0,external_react_.useState)(null);
    const isMenuOpen = Boolean(anchorEl);
    const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);
    if (true) return null;
    (0,external_react_.useEffect)(()=>{
        if (status === "unauthenticated") {
            router.replace("/login");
        }
    }, [
        status
    ]);
    if (session) {
        // if (status === "loading") {
        //   return <p>loading</p>
        // }
        // if (status === "unauthenticated") {
        //   router.replace("/login")
        // }
        //   const handleProfileMenuOpen = (event) => {
        //     setAnchorEl(event.currentTarget);
        //   };
        //   const handleMobileMenuClose = () => {
        //     setMobileMoreAnchorEl(null);
        //   };
        //   const handleMenuClose = () => {
        //     setAnchorEl(null);
        //     handleMobileMenuClose();
        //   };
        //   const handleMobileMenuOpen = (event) => {
        //     setMobileMoreAnchorEl(event.currentTarget);
        //   };
        //   const menuId = 'primary-search-account-menu';
        //   const renderMenu = (
        //     <Menu
        //       anchorEl={anchorEl}
        //       anchorOrigin={{
        //         vertical: 'top',
        //         horizontal: 'right',
        //       }}
        //       id={menuId}
        //       keepMounted
        //       transformOrigin={{
        //         vertical: 'top',
        //         horizontal: 'right',
        //       }}
        //       open={isMenuOpen}
        //       onClose={handleMenuClose}
        //     >
        //       <MenuItem onClick={handleMenuClose}>Profile</MenuItem>
        //       <MenuItem onClick={handleMenuClose}>My account</MenuItem>
        //     </Menu>
        //   );
        //   const mobileMenuId = 'primary-search-account-menu-mobile';
        //   const renderMobileMenu = (
        //     <Menu
        //       anchorEl={mobileMoreAnchorEl}
        //       anchorOrigin={{
        //         vertical: 'top',
        //         horizontal: 'right',
        //       }}
        //       id={mobileMenuId}
        //       keepMounted
        //       transformOrigin={{
        //         vertical: 'top',
        //         horizontal: 'right',
        //       }}
        //       open={isMobileMenuOpen}
        //       onClose={handleMobileMenuClose}
        //     >
        //       <MenuItem>
        //         <IconButton size="large" aria-label="show 4 new mails" color="inherit">
        //           <Badge badgeContent={4} color="error">
        //             <MailIcon />
        //           </Badge>
        //         </IconButton>
        //         <p>Messages</p>
        //       </MenuItem>
        //       <MenuItem>
        //         <IconButton
        //           size="large"
        //           aria-label="show 17 new notifications"
        //           color="inherit"
        //         >
        //           <Badge badgeContent={17} color="error">
        //             <NotificationsIcon />
        //           </Badge>
        //         </IconButton>
        //         <p>Notifications</p>
        //       </MenuItem>
        //       <MenuItem onClick={handleProfileMenuOpen}>
        //         <IconButton
        //           size="large"
        //           aria-label="account of current user"
        //           aria-controls="primary-search-account-menu"
        //           aria-haspopup="true"
        //           color="inherit"
        //         >
        //           <AccountCircle />
        //         </IconButton>
        //         <p>Profile</p>
        //       </MenuItem>
        //     </Menu>
        //   );
        const handleDrawer = ()=>{
            setDrawer(!isDrawerOpen);
        };
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
            sx: {
                flexGrow: 1,
                top: "0",
                left: "0",
                width: "100%"
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((AppBar_default()), {
                    position: "fixed",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ToolbarStyle, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                size: "large",
                                edge: "start",
                                "aria-label": "open drawer",
                                onClick: handleDrawer,
                                sx: {
                                    mr: 2,
                                    color: theme.palette.secondary.contrastText
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((icons_material_Menu_default()), {})
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "h6",
                                noWrap: true,
                                component: "div",
                                sx: {
                                    xs: "none",
                                    sm: "block",
                                    color: theme.palette.primary.main,
                                    "&:hover": {
                                        cursor: "pointer"
                                    }
                                },
                                onClick: ()=>router.push("/home"),
                                children: "AWExpress"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Search, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(SearchIconWrapper, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Search_default()), {})
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(StyledInputBase, {
                                        placeholder: "Search…",
                                        inputProps: {
                                            "aria-label": "search"
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    flexGrow: 1
                                }
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Box_default()), {
                                sx: {
                                    display: {
                                        xs: "none",
                                        md: "flex"
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                        size: "large",
                                        "aria-label": "show 4 new mails",
                                        sx: {
                                            color: theme.palette.secondary.contrastText
                                        },
                                        onClick: ()=>router.push("/sell"),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Badge_default()), {
                                            badgeContent: 0,
                                            color: "error",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Sell_default()), {})
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                        size: "large",
                                        "aria-label": "show 17 new notifications",
                                        color: "inherit",
                                        sx: {
                                            color: theme.palette.secondary.contrastText
                                        },
                                        onClick: ()=>router.push("/cart"),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Badge_default()), {
                                            badgeContent: 3,
                                            color: "error",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((ShoppingCart_default()), {})
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                        size: "large",
                                        edge: "end",
                                        "aria-label": "account of current user",
                                        //aria-controls={menuId}
                                        "aria-haspopup": "true",
                                        //onClick={handleProfileMenuOpen}
                                        color: "inherit",
                                        children: session && /*#__PURE__*/ jsx_runtime_.jsx(AccountMenu, {
                                            user: session.user
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Box_default()), {
                                sx: {
                                    display: {
                                        xs: "flex",
                                        md: "none"
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                    size: "large",
                                    "aria-label": "show more",
                                    //aria-controls={mobileMenuId}
                                    "aria-haspopup": "true",
                                    //onClick={handleMobileMenuOpen}
                                    color: "inherit",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((MoreVert_default()), {})
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(PersistentDrawerLeft, {
                    open: isDrawerOpen
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(MainStyle, {
                    children: children
                })
            ]
        });
    } else {
        return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
    }
}
async function getServerSideProps(context) {
    return {
        props: {
            session: await getServerSession(context.req, context.res, authOptions)
        }
    };
}


/***/ })

};
;